module.exports = function (options) {

    //Import the mock data json file

    const mockData = require('./MOCK_DATA.json');



    //Add the patterns and their corresponding functions

    this.add('role:product,cmd:getProductURL', ProductURL);

    this.add('role:product,cmd:getProductName', getProductName);





    //To DO: add the pattern functions and describe the logic inside the function
    


    function ProductURL(msg, respond) {

        if(msg.productId) {
           const mydata = JSON.parse(mockData);
            var res = msg.productId;
            //var res = mockData[[2],"product_url"];
            console.log(mydata);

            respond(null, {result: res});

        }

        else {

            respond(null, {result: 'negativ'});

        }

    }
    function getProductName (product_id, respond) {

        if(mockData.product_id) {

            var res = mockData.product_name;

            respond(null, {result: res});

        }

        else {

            respond(null, {result: 'testname'});

        }

    }

}