module.exports = function (options) {

    //Import the mock data json file

    const mockData = require('./MOCK_DATA.json');



    //Add the patterns and their corresponding functions

    this.add('role:product,cmd:getProductURL', ProductURL);

    this.add('role:product,cmd:getProductName', ProductName);





    //To DO: add the pattern functions and describe the logic inside the function
    


    function ProductURL(msg, respond) {

        if(msg.productId) {
           
            var res = mockData[msg.productId-1].product_url;

            respond(null, {result: res});

        }

        else {

            respond(null, {result: ''});

        }

    }
    function ProductName (msg, respond) {

        if(msg.productId) {

            var res = mockData[msg.productId-1].product_name;

            respond(null, {result: res});

        }

        else {

            respond(null, {result: ''});

        }

    }

}